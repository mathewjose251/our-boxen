# Plex Puppet Module for Boxen
[![Build Status](https://travis-ci.org/boxen/puppet-plex.png?branch=master)](https://travis-ci.org/boxen/puppet-plex)

## Usage

```puppet
include plex
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
